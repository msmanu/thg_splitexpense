# THG-exp-splitter
This repository is created only for the members of THG. 
